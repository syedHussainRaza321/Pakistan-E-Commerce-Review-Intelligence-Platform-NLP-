"""
Component 4: Streamlit Dashboard for Daraz Review Intelligence (POC)
-------------------------------------------------------------------
Run with: streamlit run app.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import json
from datetime import datetime
import sys
import os

# Import our previously built components
# Assumes the following files are in the same directory:
#   - review_scraper.py
#   - nlp_pipeline.py
#   - roman_urdu_handler.py
try:
    from review_scraper import DarazReviewScraper
    from nlp_pipeline import (
        RomanUrduNormaliser,
        AspectSentimentAnalyzer,
        FakeReviewDetector,
        ReviewIntelligencePipeline
    )
    from roman_urdu_handler import RomanUrduNormaliser as RomanUrduNormaliserAlt
    MODULES_AVAILABLE = True
except ImportError as e:
    st.error(f"Required modules not found: {e}\nPlease ensure all component files are in the same directory.")
    MODULES_AVAILABLE = False
    # For demo purposes, we will use mock data
    st.info("Running in DEMO mode with mock data because modules are missing.")

# Page configuration
st.set_page_config(
    page_title="Daraz Review Intelligence",
    page_icon="📊",
    layout="wide"
)

# Title and description
st.title("📊 Daraz Review Intelligence Engine")
st.markdown("""
**Aspect‑based sentiment analysis + fake review detection for Daraz.pk**  
Enter a product URL below to scrape its reviews and get actionable insights.
""")

# Sidebar – configuration
st.sidebar.header("Configuration")
max_pages = st.sidebar.slider("Number of review pages to scrape", 1, 10, 2)
use_mock = st.sidebar.checkbox("Use mock data (skip scraping)", value=False)

# Main input
product_url = st.text_input(
    "Daraz Product URL",
    placeholder="https://www.daraz.pk/products/...",
    help="Example: https://www.daraz.pk/products/iphone-15-i1234567.html"
)

# Helper function for mock reviews (for testing without scraping)
def get_mock_reviews():
    return [
        {"reviewer": "user1", "rating": 5, "review_text": "bohat acha product hai, delivery fast thi", "date": "2024-01-01", "helpful_count": "5"},
        {"reviewer": "user2", "rating": 2, "review_text": "bakwas quality, packing kharab", "date": "2024-01-02", "helpful_count": "2"},
        {"reviewer": "user3", "rating": 4, "review_text": "price theek hai but service bekar", "date": "2024-01-03", "helpful_count": "3"},
        {"reviewer": "user4", "rating": 5, "review_text": "Best product ever! Must buy! Amazing!", "date": "2024-01-04", "helpful_count": "10"},
        {"reviewer": "user5", "rating": 3, "review_text": "Delivery was on time, product okay", "date": "2024-01-05", "helpful_count": "1"},
    ]

# Main logic
if st.button("🚀 Analyse Product", type="primary"):
    if not product_url and not use_mock:
        st.warning("Please enter a product URL or enable 'Use mock data'.")
        st.stop()

    # Progress tracking
    progress_bar = st.progress(0)
    status_text = st.empty()

    try:
        # ----- Step 1: Scrape reviews -----
        status_text.text("Step 1/4: Scraping reviews...")
        progress_bar.progress(10)

        if use_mock or not MODULES_AVAILABLE:
            reviews = get_mock_reviews()
            st.info("Using mock review data (scraping disabled).")
        else:
            scraper = DarazReviewScraper(headless=True, timeout=900000)
            reviews = scraper.scrape_product_reviews(product_url, max_pages=max_pages)
            if not reviews:
                st.error("No reviews found. The product may have no reviews or the URL is invalid.")
                st.stop()

        st.success(f"Scraped {len(reviews)} reviews.")
        progress_bar.progress(30)

        # ----- Step 2: Initialise pipeline components -----
        status_text.text("Step 2/4: Initialising NLP pipeline...")
        progress_bar.progress(40)

        # Roman Urdu normaliser
        roman_norm = RomanUrduNormaliser() if 'RomanUrduNormaliser' in dir() else RomanUrduNormaliserAlt()
        # Aspect sentiment analyzer (requires Ollama running with llama3)
        # For demo, we can use a mock analyzer if Ollama not available
        try:
            aspect_analyzer = AspectSentimentAnalyzer(model_name="llama3")
        except Exception as e:
            st.warning(f"Could not initialise LLM: {e}. Using rule‑based fallback for demo.")
            # Simple fallback: assign random/rule-based sentiment for demonstration
            class MockAspectAnalyzer:
                def analyse(self, text):
                    return {"Delivery": "Positive", "Quality": "Negative", "Price": "Not Mentioned", "Packaging": "Not Mentioned", "Service": "Not Mentioned"}
            aspect_analyzer = MockAspectAnalyzer()

        # Fake review detector
        fake_detector = FakeReviewDetector()  # trains on demo data

        # Full pipeline
        pipeline = ReviewIntelligencePipeline(roman_norm, aspect_analyzer, fake_detector)
        progress_bar.progress(50)

        # ----- Step 3: Process each review -----
        status_text.text("Step 3/4: Analysing reviews (this may take a moment)...")
        progress_bar.progress(60)

        enriched_reviews = []
        total = len(reviews)
        for i, rev in enumerate(reviews):
            if not rev.get('review_text'):
                continue
            analysis = pipeline.process_review(rev['review_text'])
            enriched_reviews.append({**rev, **analysis})
            # Update progress within this step
            progress_bar.progress(60 + int(30 * (i+1)/total))

        progress_bar.progress(90)

        # ----- Step 4: Display results -----
        status_text.text("Step 4/4: Generating dashboard...")
        df = pd.DataFrame(enriched_reviews)

        # Compute aggregated metrics
        # Aspect sentiment distribution
        aspect_columns = [col for col in df.columns if col in ['Delivery', 'Quality', 'Price', 'Packaging', 'Service']]
        aspect_sent_counts = {}
        for asp in aspect_columns:
            counts = df[asp].value_counts()
            aspect_sent_counts[asp] = counts.to_dict()

        # Trust score = (1 - average fake probability) * 100
        avg_fake = df['fake_probability'].mean() if 'fake_probability' in df else 0
        trust_score = (1 - avg_fake) * 100

        # Top positive & negative aspects
        # Count positive mentions per aspect
        pos_counts = {asp: (df[asp] == 'Positive').sum() for asp in aspect_columns}
        neg_counts = {asp: (df[asp] == 'Negative').sum() for asp in aspect_columns}
        top_positive = max(pos_counts, key=pos_counts.get) if any(pos_counts.values()) else "None"
        top_negative = max(neg_counts, key=neg_counts.get) if any(neg_counts.values()) else "None"

        progress_bar.progress(100)
        status_text.text("Analysis complete!")

        # ----- Dashboard output -----
        st.header("📈 Results Dashboard")

        # Row 1: Key metrics
        col1, col2, col3 = st.columns(3)
        col1.metric("Overall Trust Score", f"{trust_score:.1f}%", help="Percentage of reviews classified as genuine")
        col2.metric("Most Positive Aspect", top_positive)
        col3.metric("Most Negative Aspect", top_negative)

        # Row 2: Aspect sentiment bar chart
        st.subheader("Sentiment by Aspect")
        # Prepare data for Plotly
        plot_data = []
        for asp, counts in aspect_sent_counts.items():
            for sentiment, count in counts.items():
                plot_data.append({"Aspect": asp, "Sentiment": sentiment, "Count": count})
        plot_df = pd.DataFrame(plot_data)
        if not plot_df.empty:
            fig = px.bar(plot_df, x="Aspect", y="Count", color="Sentiment", barmode="group",
                         title="Distribution of Aspect Sentiments")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No aspect sentiment data available.")

        # Row 3: Fake review flags table
        st.subheader("⚠️ Potentially Fake Reviews")
        fake_reviews = df[df['fake_probability'] > 0.7].copy()
        if not fake_reviews.empty:
            show_cols = ['reviewer', 'review_text', 'fake_probability']
            st.dataframe(fake_reviews[show_cols].style.format({'fake_probability': "{:.2%}"}))
        else:
            st.success("No high‑probability fake reviews detected!")

        # Row 4: Roman Urdu example (show first review that contains Roman Urdu patterns)
        st.subheader("🔤 Roman Urdu Normalisation Example")
        # Find a review that actually changed after normalisation
        sample_row = None
        for idx, row in df.iterrows():
            if row.get('normalised_review') and row['normalised_review'] != row['original_review']:
                sample_row = row
                break
        if sample_row is not None:
            col1, col2 = st.columns(2)
            col1.markdown("**Original (Roman Urdu)**")
            col1.info(sample_row['original_review'])
            col2.markdown("**Normalised (English‑like)**")
            col2.success(sample_row['normalised_review'])
        else:
            st.write("No Roman Urdu review found in the sample. Try another product or enable mock data for demonstration.")

        # Optional: Download results as CSV
        st.download_button(
            label="📥 Download results as CSV",
            data=df.to_csv(index=False).encode('utf-8'),
            file_name=f"daraz_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
        )

    except Exception as e:
        st.error(f"An error occurred: {e}")
        st.stop()