"""
Component 3: Roman Urdu Handling for E‑commerce Reviews
-------------------------------------------------------
Purpose: Normalise Roman Urdu text to English‑like tokens.
Method: Dictionary mapping + regular expression replacements.
Output: Normalised string that can be fed into LLM or traditional NLP models.

The dictionary can be easily extended with more words/phrases.
For a POC, covering 50-100 common words is sufficient.
"""

import re
from typing import Dict, List, Optional


class RomanUrduNormaliser:
    """
    Normaliser for Roman Urdu text commonly found in Daraz reviews.
    Converts to a standardised English‑like form.
    """

    def __init__(self, custom_mapping: Optional[Dict[str, str]] = None):
        """
        Args:
            custom_mapping: Additional word replacements (dict of lowercased patterns).
                           Overrides the default mapping.
        """
        # Default mapping – hand‑crafted from real Daraz review samples
        self.default_mapping = {
            # Sentiment words
            "acha": "good",
            "accha": "good",
            "bohat": "very",
            "bohot": "very",
            "bht": "very",
            "bakwas": "terrible",
            "bekar": "useless",
            "bekaar": "useless",
            "kharab": "bad",
            "zabardast": "excellent",
            "maza": "enjoyable",
            "thik": "okay",
            "theek": "okay",
            "na": "not",
            "nahi": "no",
            "nahin": "no",
            "nahee": "no",
            "hain": "is",
            "hai": "is",
            "tha": "was",
            "thi": "was",
            "the": "were",
            "ho": "be",
            # Product aspects
            "delivery": "delivery",
            "packing": "packaging",
            "quality": "quality",
            "qty": "quantity",
            "price": "price",
            "service": "service",
            # Common words
            "to": "to",
            "ka": "of",
            "ki": "of",
            "ke": "of",
            "k": "of",
            "mein": "in",
            "main": "in",
            "me": "in",
            "or": "and",
            "aur": "and",
            "yeh": "this",
            "ye": "this",
            "woh": "that",
            "wo": "that",
            "hai": "is",
            "he": "is",
            "ko": "to",
            "se": "from",
            "liye": "for",
        }
        # Merge custom mapping if provided
        self.mapping = {}
        self.mapping.update(self.default_mapping)
        if custom_mapping:
            self.mapping.update(custom_mapping)

        # Pre‑compile regex patterns for speed (word boundaries)
        self.patterns = []
        for urdu_word, eng_word in self.mapping.items():
            # Match whole word only (case‑insensitive)
            pattern = re.compile(r'\b' + re.escape(urdu_word) + r'\b', re.IGNORECASE)
            self.patterns.append((pattern, eng_word))

    def normalise(self, text: str) -> str:
        """
        Normalise a Roman Urdu string.
        Steps:
        1. Lowercase.
        2. Replace known words using word‑boundary patterns.
        3. Collapse multiple spaces.
        """
        if not text:
            return ""

        text = text.lower()
        # Apply each replacement
        for pattern, replacement in self.patterns:
            text = pattern.sub(replacement, text)

        # Clean up extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def normalise_batch(self, texts: List[str]) -> List[str]:
        """Apply normalisation to a list of strings."""
        return [self.normalise(t) for t in texts]

    def add_mapping(self, urdu_word: str, english_word: str):
        """Dynamically add or update a mapping."""
        self.mapping[urdu_word.lower()] = english_word.lower()
        pattern = re.compile(r'\b' + re.escape(urdu_word.lower()) + r'\b')
        self.patterns.append((pattern, english_word.lower()))


# ========================
# Example Usage & Testing
# ========================
if __name__ == "__main__":
    # Create normaliser
    norm = RomanUrduNormaliser()

    # Test sentences (mix of English, Roman Urdu, and code‑switching)
    test_reviews = [
        "bohat acha product hai, delivery bht fast thi",
        "packing bakwas tha, quality kharab",
        "price theek hai but service bekar",
        "zabardast! maza aa gaya",
        "yeh product na lo, time waste hai",
        "Delivery was on time, but packing could be better",
        "Bohat ACHA! 5 stars",
    ]

    print("Roman Urdu Normalisation Demo\n")
    for original in test_reviews:
        normalised = norm.normalise(original)
        print(f"Original:    {original}")
        print(f"Normalised:  {normalised}")
        print("-" * 50)

    # Optional: save mapping to file for later extension
    import json
    with open("roman_urdu_mapping.json", "w", encoding="utf-8") as f:
        json.dump(norm.mapping, f, ensure_ascii=False, indent=2)
    print("Mapping saved to roman_urdu_mapping.json")