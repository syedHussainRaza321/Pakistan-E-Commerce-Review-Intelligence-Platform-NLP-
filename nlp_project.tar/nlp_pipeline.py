"""
NLP Pipeline for Daraz Review Intelligence (POC)
------------------------------------------------
Components:
2a - Aspect-Based Sentiment Analysis (ABSA) using LangChain + LLaMA-3 (Ollama)
2b - Fake Review Detection using Scikit-learn (Logistic Regression)

Assumptions:
- Ollama is running locally with 'llama3' model (or any other supported).
- spaCy model 'en_core_web_sm' is installed (python -m spacy download en_core_web_sm)
- For fake review detection, we use a small pre-trained model or train on a public dataset.
  This POC includes a lightweight training on a built-in mini dataset (for demonstration).
  In production, replace with larger dataset (e.g., Yelp fake reviews).
"""

import json
import re
from typing import List, Dict, Any, Optional
from collections import defaultdict

# NLP & ML
import spacy
# from langchain.llms import Ollama
# from langchain.chains import LLMChain
# from langchain.prompts import PromptTemplate
# from langchain.output_parsers import PydanticOutputParser
from langchain_ollama import ChatOllama as Ollama
from langchain_classic.chains import LLMChain
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import PydanticOutputParser 
from pydantic import BaseModel, Field
import pickle
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from roman_urdu_handler import RomanUrduNormaliser  # Assuming this is in the same directory or installed as a package

# ========================
# Aspect-Based Sentiment Analysis (Component 2a)
# ========================

class AspectSentimentOutput(BaseModel):
    """Expected JSON schema from LLM."""
    aspects: Dict[str, str] = Field(
        description="Dictionary mapping aspect names to sentiment: Positive/Negative/Not Mentioned"
    )

# Predefined aspect list (extendable)
DEFAULT_ASPECTS = ["Delivery", "Quality", "Price", "Packaging", "Service"]

class AspectSentimentAnalyzer:
    def __init__(self, model_name: str = "llama3", aspects: List[str] = None):
        """
        Args:
            model_name: Ollama model name (e.g., 'llama3', 'mistral')
            aspects: List of aspect labels to extract.
        """
        self.aspects = aspects or DEFAULT_ASPECTS
        self.llm = Ollama(model=model_name, temperature=0.0)
        self.parser = PydanticOutputParser(pydantic_object=AspectSentimentOutput)

        prompt_template = """
You are an expert sentiment analyst for e-commerce product reviews.
Analyse the following review and output sentiment for each aspect in the list.

Review: {review}

Aspects to analyse: {aspects}

Return ONLY a JSON object following this schema:
{format_instructions}

Make sure each aspect gets exactly one of: Positive, Negative, Not Mentioned.
"""
        self.prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["review", "aspects"],
            partial_variables={"format_instructions": self.parser.get_format_instructions()}
        )
        self.chain = LLMChain(llm=self.llm, prompt=self.prompt)

    def analyse(self, review_text: str) -> Dict[str, str]:
        """
        Run ABSA on a single review.
        Returns dict: aspect -> sentiment.
        """
        try:
            result = self.chain.run(review=review_text, aspects=", ".join(self.aspects))
            parsed = self.parser.parse(result)
            return parsed.aspects
        except Exception as e:
            print(f"ABSA error: {e}")
            # Fallback: all aspects Not Mentioned
            return {asp: "Not Mentioned" for asp in self.aspects}


# ========================
# Fake Review Detection (Component 2b)
# ========================

class FakeReviewDetector:
    """
    Lightweight fake review classifier using TF-IDF + Logistic Regression.
    For POC, we train on a small built-in dataset (demo).
    In real use, replace with a larger public dataset (e.g., Yelp fake reviews).
    """
    def __init__(self, model_path: Optional[str] = None):
        self.pipeline = None
        if model_path:
            self.load(model_path)
        else:
            self._train_on_demo_data()

    def _train_on_demo_data(self):
        """
        Demo training data: 10 genuine + 10 fake reviews (toy examples).
        Real project should use proper dataset.
        """
        # Toy examples (replace with real data for better results)
        genuine_reviews = [
            "The product quality is excellent and delivery was fast.",
            "Very happy with this purchase. Highly recommended.",
            "Good value for money. Works as described.",
            "Decent product, but packaging could be improved.",
            "Arrived on time, no issues. Will buy again."
        ]
        fake_reviews = [
            "Best product ever! I love it! Amazing! Must buy!",
            "Five stars! Perfect! Superb! Awesome!",
            "Wow wow wow! Great great great!",
            "Terrible product but I give five stars for no reason.",
            "This changed my life! So so amazing!"
        ]
        texts = genuine_reviews + fake_reviews
        labels = [0]*len(genuine_reviews) + [1]*len(fake_reviews)  # 0=real, 1=fake

        self.pipeline = Pipeline([
            ('tfidf', TfidfVectorizer(ngram_range=(1,2), max_features=100)),
            ('clf', LogisticRegression())
        ])
        self.pipeline.fit(texts, labels)
        print("Fake review detector trained on demo data (toy accuracy).")

    def predict(self, review_text: str) -> float:
        """Return probability of being fake (0..1)."""
        if not self.pipeline:
            return 0.5
        prob = self.pipeline.predict_proba([review_text])[0]
        return prob[1]  # probability of class 1 (fake)

    def save(self, path: str):
        with open(path, 'wb') as f:
            pickle.dump(self.pipeline, f)

    def load(self, path: str):
        with open(path, 'rb') as f:
            self.pipeline = pickle.load(f)


# ========================
# Main Pipeline Orchestrator
# ========================

class ReviewIntelligencePipeline:
    """
    End-to-end pipeline:
    1. Normalise Roman Urdu (if any)
    2. Aspect sentiment analysis
    3. Fake review detection
    """
    def __init__(self, 
                 urdu_normaliser: RomanUrduNormaliser,
                 aspect_analyzer: AspectSentimentAnalyzer,
                 fake_detector: FakeReviewDetector):
        self.urdu_normaliser = urdu_normaliser
        self.aspect_analyzer = aspect_analyzer
        self.fake_detector = fake_detector

    def process_review(self, review_text: str) -> Dict[str, Any]:
        """Process a single review text and return structured output."""
        # Step 1: Normalise Roman Urdu (if applicable)
        normalised = self.urdu_normaliser.normalise(review_text)

        # Step 2: Aspect sentiment
        aspect_sentiment = self.aspect_analyzer.analyse(normalised)

        # Step 3: Fake probability
        fake_prob = self.fake_detector.predict(normalised)

        return {
            "original_review": review_text,
            "normalised_review": normalised,
            "aspect_sentiment": aspect_sentiment,
            "fake_probability": round(fake_prob, 3)
        }

    def process_batch(self, reviews: List[Dict]) -> List[Dict]:
        """
        Process a batch of review objects (as returned by scraper).
        Each review dict must have a 'review_text' key.
        Returns enriched dicts.
        """
        results = []
        for rev in reviews:
            text = rev.get('review_text', '')
            if not text:
                # Skip empty reviews
                results.append({**rev, "error": "empty_review"})
                continue
            analysis = self.process_review(text)
            # Merge original review data with analysis
            enriched = {**rev, **analysis}
            results.append(enriched)
        return results


# ========================
# Example Usage
# ========================
if __name__ == "__main__":
    # 1. Load spaCy (optional – used for preprocessing if needed)
    try:
        nlp = spacy.load("en_core_web_sm")
        print("spaCy loaded")
    except OSError:
        print("spaCy model not found. Run: python -m spacy download en_core_web_sm")

    # 2. Initialise components
    urdu_norm = RomanUrduNormaliser()
    # Note: Requires Ollama running with 'llama3' model.
    # If not available, replace with 'mistral' or set use_local_llm=False.
    absa = AspectSentimentAnalyzer(model_name="llama3")
    fake_det = FakeReviewDetector()  # trains on demo data

    # 3. Create pipeline
    pipeline = ReviewIntelligencePipeline(urdu_norm, absa, fake_det)

    # 4. Test on sample reviews (including Roman Urdu)
    sample_reviews = [
        "Delivery was super fast but the quality is not good",
        "bohat acha product hai. price bhi theek hai",
        "bakwas packing and delivery took 10 days",
    ]

    for review in sample_reviews:
        result = pipeline.process_review(review)
        print("\n--- Review ---")
        print(f"Original: {result['original_review']}")
        print(f"Normalised: {result['normalised_review']}")
        print(f"Aspect sentiment: {result['aspect_sentiment']}")
        print(f"Fake probability: {result['fake_probability']}")

    # 5. Example: load scraped JSON and process batch
    # import json
    # with open("daraz_reviews.json", "r", encoding="utf-8") as f:
    #     scraped_reviews = json.load(f)
    # enriched = pipeline.process_batch(scraped_reviews)
    # with open("enriched_reviews.json", "w") as f:
    #     json.dump(enriched, f, indent=2)