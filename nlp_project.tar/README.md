
# Daraz Review Intelligence Engine – POC

**Aspect‑based sentiment analysis + fake review detection for Daraz.pk**
*NLP Semester Project – Proof of Concept*

---

## 📌 Overview

This project demonstrates a complete pipeline that:

- Scrapes product reviews from Daraz.pk
- Normalises **Roman Urdu** text (e.g., `"bohat acha"` → `"very good"`)
- Performs **aspect‑based sentiment analysis** (Delivery, Quality, Price, Packaging, Service)
- Detects **fake reviews** using a machine learning classifier
- Displays results in an interactive **Streamlit dashboard**

The POC proves the core technical claim:

> *“We can take a raw Daraz product review and automatically extract aspect‑level sentiments AND flag whether it is likely fake – including reviews written in Roman Urdu.”*

---

## 🗂️ Project Structure

daraz_review_intelligence/
│
├── daraz_review_scraper.py # Component 1 – Scrapes reviews from Daraz
├── roman_urdu_handler.py # Component 3 – Roman Urdu normalisation
├── nlp_pipeline.py # Component 2 – ABSA + fake detection
├── app.py # Component 4 – Streamlit dashboard (integration)
├── requirements.txt # Python dependencies
└── README.md # This file


```markdown
## ⚙️ Setup Instructions (Windows / macOS / Linux)

### 1. Clone or download the project folder
Place all files in a single directory.

### 2. Create a virtual environment (recommended)
```bash
python -m venv venv
source venv/bin/activate      # Linux/macOS
venv\Scripts\activate         # Windows
```


### 3. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 4. Download spaCy language model

```bash
python -m spacy download en_core_web_sm
```

### 5. Install Playwright browser (for scraping)

```bash
playwright install chromium
```

### 6. Install Ollama (for local LLaMA‑3 – optional but recommended)

- **Windows**: Download and run `OllamaSetup.exe` from [ollama.com](https://ollama.com/download)
- **macOS/Linux**: `curl -fsSL https://ollama.com/install.sh | sh`
- Then pull the model:
  ```bash
  ollama pull llama3
  ```
- Keep Ollama running in the background:
  ```bash
  ollama serve
  ```

> *If Ollama is not installed, the dashboard will fall back to a rule‑based aspect analyzer – the POC will still run using mock data.*

---

## 🚀 Running the Application

1. **Activate your virtual environment** (if used).
2. **Navigate to the project folder**.
3. **Launch Streamlit**:
   ```bash
   streamlit run app.py
   ```
4. Your default browser will open at `http://localhost:8501`.

---

## 🧪 Using the Dashboard

### Option A – Mock Data (for quick testing, no scraping or LLM needed)

- On the sidebar, check **“Use mock data”**.
- Click **“Analyse Product”** (URL can be left empty).
- View results – aspect charts, fake review table, Roman Urdu normalisation example.

### Option B – Real Daraz Product (scraping + Ollama)

- Uncheck “Use mock data”.
- Enter a valid Daraz product URL (e.g., `https://www.daraz.pk/products/...`).
- Set the number of review pages to scrape (start with 1–2).
- Click **“Analyse Product”** and wait for processing.

The dashboard will show:

- Overall Trust Score (based on fake review probability)
- Most positive / most negative aspect
- Interactive bar chart of sentiment per aspect
- Table of highly suspect fake reviews
- Side‑by‑side example of Roman Urdu normalisation

---

## 🔧 Troubleshooting

| Issue                         | Solution                                                                                            |
| ----------------------------- | --------------------------------------------------------------------------------------------------- |
| `ModuleNotFoundError`       | Make sure all `.py` files are in the same directory. Re‑run `pip install -r requirements.txt`. |
| Playwright browser missing    | Run `playwright install chromium` again.                                                          |
| Ollama connection error       | Verify that `ollama serve` is running in a separate terminal.                                     |
| No reviews scraped            | The product URL may have no reviews. Try another product or use**mock data**.                 |
| Streamlit port already in use | Run `streamlit run app.py --server.port 8502`                                                     |

---

## 📦 Dependencies

Listed in `requirements.txt`:

- `streamlit` – dashboard framework
- `pandas`, `plotly` – data manipulation and visualisation
- `playwright`, `beautifulsoup4` – web scraping
- `langchain`, `ollama` – LLM orchestration and local inference
- `spacy` – optional preprocessing
- `scikit-learn` – fake review classifier
- `pydantic` – JSON schema validation

---

## ✅ POC Completion Checklist

- [X] Scraper fetches real Daraz reviews
- [X] Roman Urdu normaliser works on mixed‑language text
- [X] Aspect sentiment extracted (English + normalised Roman Urdu)
- [X] Fake review probability assigned
- [X] Interactive dashboard ties all components together
- [X] Runs locally without cloud services or paid APIs

---

## 📝 Notes for Submission

- This is a **proof of concept**, not a production system.
- No authentication, database, or multi‑user support – by design.
- The fake review classifier is trained on a small demo dataset; for real use, replace with a larger public dataset (e.g., Yelp fake reviews).
- The Roman Urdu dictionary can be expanded automatically using a small corpus.

---

## 👥 Team

*[Muhammad Rayyan Jafer (31), Amos Shehzad (46), Syed Hussain Raza (41), Muhammad Rizwan (13)]*
*Natural Language Processing Course – [BSDSF23M, 6th Semester]*

---

## 📄 License

This project is for academic purposes only. Scraping Daraz may be subject to their terms of service – use responsibly and at a low rate.
