"""
Daraz Review Scraper – Robust Version
- Works even if there is no Reviews tab
- Scrolls to trigger lazy loading
- Uses multiple possible selectors for review containers
- Handles products with zero reviews gracefully
"""

import json
import csv
import time
import random
import logging
from typing import List, Dict
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeout

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class DarazReviewScraper:
    def __init__(self, headless: bool = True, timeout: int = 60000):
        self.headless = headless
        self.timeout = timeout

    # Multiple possible selectors for review items (updated based on actual Daraz)
    REVIEW_ITEM_SELECTORS = [
        "div.review-item",          # common class
        ".item-module",             # older class
        "div[data-tag='review-item']",
        ".comment-list > div",
        ".mod-reviews .item",       # fallback
        ".review-list .review-item"
    ]

    REVIEW_TEXT_SELECTORS = [
        "div.content",
        ".review-content",
        ".item-content .content",
        ".review-text"
    ]

    RATING_SELECTORS = [
        ".star-rating-star",
        ".i-rate-star.yellow",
        ".container-star"
    ]

    def _random_delay(self, min_sec: float = 1.0, max_sec: float = 2.5):
        time.sleep(random.uniform(min_sec, max_sec))

    def _extract_rating(self, card_soup) -> int:
        """Extract numeric rating (1-5) from a review card."""
        from bs4 import BeautifulSoup
        # First try: count filled stars by class
        stars = card_soup.select('.star-rating-star.yellow, .i-rate-star.yellow')
        if stars:
            return len(stars)
        # Second: look for inline width style
        star_container = card_soup.select_one('.container-star')
        if star_container and star_container.get('style'):
            style = star_container['style']
            import re
            match = re.search(r'width:\s*(\d+(?:\.\d+)?)%', style)
            if match:
                percent = float(match.group(1))
                return round(percent / 20)  # 20% per star
        return 0

    def _get_reviews_from_html(self, html: str) -> List[Dict]:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        reviews = []

        # Try all possible review item selectors
        review_cards = []
        for selector in self.REVIEW_ITEM_SELECTORS:
            review_cards = soup.select(selector)
            if review_cards:
                logger.debug(f"Found review items using selector: {selector}")
                break

        if not review_cards:
            logger.warning("No review items found with any selector")
            return []

        for card in review_cards:
            try:
                # Find review text
                review_text = ""
                for text_sel in self.REVIEW_TEXT_SELECTORS:
                    elem = card.select_one(text_sel)
                    if elem:
                        review_text = elem.get_text(strip=True)
                        break
                if not review_text:
                    continue

                # Rating
                rating = self._extract_rating(card)

                # Reviewer name – try common patterns
                reviewer = "Anonymous"
                reviewer_elem = card.select_one(".middle span:first-child, .username, .reviewer-name")
                if reviewer_elem:
                    reviewer = reviewer_elem.get_text(strip=True)

                # Date
                date_str = ""
                date_elem = card.select_one(".title.right, .review-date, .date")
                if date_elem:
                    date_str = date_elem.get_text(strip=True)

                # Helpful count
                helpful = "0"
                helpful_elem = card.select_one(".left-content span, .helpful-count")
                if helpful_elem:
                    helpful = helpful_elem.get_text(strip=True)

                reviews.append({
                    'reviewer': reviewer,
                    'rating': rating,
                    'review_text': review_text,
                    'date': date_str,
                    'helpful_count': helpful
                })
            except Exception as e:
                logger.error(f"Error parsing a review card: {e}")
                continue
        return reviews

    def scrape_product_reviews(self, product_url: str, max_pages: int = 3) -> List[Dict]:
        logger.info(f"Starting scrape for: {product_url}")
        all_reviews = []

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=self.headless)
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                viewport={'width': 1280, 'height': 800}
            )
            page = context.new_page()
            page.set_default_timeout(self.timeout)

            logger.info(f"Navigating to: {product_url}")
            page.goto(product_url, wait_until="domcontentloaded")
            self._random_delay(2, 4)

            # Scroll down to trigger lazy-loaded reviews
            logger.info("Scrolling down to load reviews...")
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            self._random_delay(2, 3)

            # Try to click on "Reviews" tab if it exists (some pages have it)
            try:
                # Look for any element that says "Reviews" (case-insensitive)
                reviews_tab = page.locator("text=/reviews/i").first
                if reviews_tab.is_visible():
                    logger.info("Clicking on Reviews tab")
                    reviews_tab.click()
                    self._random_delay(2, 3)
                else:
                    logger.info("No Reviews tab found – assuming reviews are already visible")
            except:
                logger.info("No Reviews tab clickable – proceeding")

            # Wait for review items to appear
            found = False
            for selector in self.REVIEW_ITEM_SELECTORS:
                try:
                    page.wait_for_selector(selector, timeout=10000)
                    logger.info(f"Review items loaded with selector: {selector}")
                    found = True
                    break
                except PlaywrightTimeout:
                    continue
            if not found:
                logger.error("Timeout: No review items appeared after scrolling and tab clicking.")
                browser.close()
                return []

            # Pagination loop
            page_num = 1
            while page_num <= max_pages:
                logger.info(f"Scraping page {page_num}...")
                html = page.content()
                batch = self._get_reviews_from_html(html)
                if not batch:
                    logger.warning(f"No reviews extracted from page {page_num}")
                    break
                all_reviews.extend(batch)
                logger.info(f"Page {page_num}: {len(batch)} reviews (total: {len(all_reviews)})")

                # Look for "Next" button
                next_btn = page.locator("a.next, button.next, a:has-text('Next'), .next-page").first
                if next_btn.is_visible() and next_btn.is_enabled():
                    next_btn.click()
                    self._random_delay(2, 4)
                    page.wait_for_timeout(3000)
                    page_num += 1
                else:
                    # Also check for "Load More" button
                    load_more = page.locator("button:has-text('Load More')").first
                    if load_more.is_visible():
                        load_more.click()
                        self._random_delay(2, 3)
                        page_num += 1
                    else:
                        logger.info("No more pages.")
                        break

            browser.close()

        logger.info(f"Scraping completed. Total reviews: {len(all_reviews)}")
        return all_reviews

    def save_to_json(self, reviews: List[Dict], filename: str):
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(reviews, f, ensure_ascii=False, indent=2)
        logger.info(f"Saved {len(reviews)} reviews to {filename}")

    def save_to_csv(self, reviews: List[Dict], filename: str):
        if not reviews:
            return
        with open(filename, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=reviews[0].keys())
            writer.writeheader()
            writer.writerows(reviews)
        logger.info(f"Saved {len(reviews)} reviews to {filename}")


if __name__ == "__main__":
    # Use a product that definitely has reviews (e.g., a popular item)
    TEST_URL = "https://www.daraz.pk/products/1-kg-1-kg-2-kg-i493946662-s2354990647.html"
    scraper = DarazReviewScraper(headless=False, timeout=60000)
    reviews = scraper.scrape_product_reviews(TEST_URL, max_pages=2)
    if reviews:
        scraper.save_to_json(reviews, "daraz_reviews.json")
        print(f"\nSample review: {reviews[0]}")
    else:
        print("No reviews scraped. The product might have zero reviews.")